use anyhow::{Context, Result};
use log::warn;
use regex::Regex;
use std::process::Command;
use std::thread;

use crate::{config, errors::GeminiError};

/// 执行带重试逻辑的 GCP 命令 (对应原脚本中的 smart_retry_gcloud 函数)
pub(super) fn run_gcloud_command_with_retry(args: &[&str]) -> Result<String> {
    let mut attempts = 0;
    let fatal_patterns = [
        "exceeded your allotted project quota",
        "PERMISSION_DENIED",
        "Billing account not configured",
        "already exists",
        "The project ID you specified is already in use by another project",
        "Caller does not have permission",
    ];

    loop {
        attempts += 1;
        let output = Command::new("gcloud")
            .args(args)
            .output()
            .context("执行 gcloud 命令失败")?;

        let stdout = String::from_utf8_lossy(&output.stdout).to_string();
        let stderr = String::from_utf8_lossy(&output.stderr).to_string();
        let full_output = format!("{}{}", stdout, stderr);

        // 检查命令是否成功且无错误信息
        if output.status.success() && !full_output.contains("ERROR:") {
            return Ok(stdout);
        }

        // 检查是否为致命错误
        for pattern in &fatal_patterns {
            if full_output.contains(pattern) {
                return Err(GeminiError::CommandError(format!(
                    "致命错误: '{}', 命令: 'gcloud {}', 输出: '{}'",
                    pattern, args.join(" "), full_output
                )).into());
            }
        }

        // 达到最大重试次数
        if attempts >= *config::MAX_RETRY_ATTEMPTS {
            return Err(GeminiError::CommandError(format!(
                "命令 'gcloud {}' 在 {} 次尝试后失败，最后输出: '{}'",
                args.join(" "), *config::MAX_RETRY_ATTEMPTS, full_output
            )).into());
        }

        // 计算重试延迟
        let delay = (attempts * 2 + rand::random::<u8>() as usize % 3) as u64;
        warn!(
            "命令 'gcloud {}' 失败 (尝试 {}/{}), 等待 {}s 后重试...",
            args.join(" "), attempts, *config::MAX_RETRY_ATTEMPTS, delay
        );
        thread::sleep(std::time::Duration::from_secs(delay));
    }
}

/// 从 gcloud 输出中解析 API 密钥 (对应原脚本中的 jq/grep 解析部分)
pub(super) fn parse_api_key_from_output(output: &str) -> Result<String> {
    // 使用正则表达式提取 keyString 值
    let re = Regex::new(r#""keyString":\s*"([^"]+)""#).context("创建正则表达式失败")?;
    let caps = re.captures(output)
        .ok_or_else(|| GeminiError::ParseError("未找到 keyString 字段".to_string()))?;

    let api_key = caps.get(1)
        .ok_or_else(|| GeminiError::ParseError("无法提取 keyString 值".to_string()))?
        .as_str();

    if api_key.is_empty() {
        return Err(GeminiError::ParseError("API 密钥为空".to_string()).into());
    }

    Ok(api_key.to_string())
}