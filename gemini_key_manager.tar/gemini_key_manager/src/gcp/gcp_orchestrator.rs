use anyhow::{Context, Result};
use log::{error, info, warn};
use std::sync::mpsc;
use std::thread;

use crate::{config, errors::GeminiError, utils};
use super::gcp_command;

/// 启用 API 并创建密钥
fn enable_api_and_create_key(project_id: &str, log_prefix: &str) -> Result<String> {
    utils::random_sleep()?;
    info!("{} 启用 Generative Language API...", log_prefix);
    gcp_command::run_gcloud_command_with_retry(&[
        "services", "enable", "generativelanguage.googleapis.com",
        "--project", project_id,
        "--quiet"
    ]).with_context(|| format!("{} 启用 API 失败", log_prefix))?;

    utils::random_sleep()?;
    info!("{} 创建 API 密钥...", log_prefix);
    let display_name = format!("gemini-key-{}", rand::random::<u8>().to_string());
    let output = gcp_command::run_gcloud_command_with_retry(&[
        "services", "api-keys", "create",
        "--project", project_id,
        "--display-name", &display_name,
        "--format", "json",
        "--quiet"
    ]).with_context(|| format!("{} 创建密钥失败", log_prefix))?;

    gcp_command::parse_api_key_from_output(&output)
        .with_context(|| format!("{} 解析密钥失败", log_prefix))
}

/// 处理新项目创建
fn process_new_project_creation(project_id: &str) -> Result<(String, String)> {
    let log_prefix = format!("[{}]", project_id);
    info!("{} 开始创建项目...", log_prefix);
    gcp_command::run_gcloud_command_with_retry(&[
        "projects", "create", project_id,
        "--name", project_id,
        "--quiet"
    ]).with_context(|| format!("{} 项目创建失败", log_prefix))?;
    info!("{} 项目创建成功", log_prefix);
    
    let api_key = enable_api_and_create_key(project_id, &log_prefix)
        .with_context(|| format!("{} 获取密钥失败", log_prefix))?;
    info!("{} 成功获取密钥！", log_prefix);
    Ok((project_id.to_string(), api_key))
}

/// 处理现有项目密钥提取
fn process_existing_project_extraction(project_id: &str) -> Result<(String, String)> {
    let log_prefix = format!("[{}]", project_id);
    info!("{} 开始处理现有项目...", log_prefix);
    let api_key = enable_api_and_create_key(project_id, &log_prefix)
        .with_context(|| format!("{} 获取密钥失败", log_prefix))?;
    info!("{} 成功获取密钥！", log_prefix);
    Ok((project_id.to_string(), api_key))
}

/// 通用的并行任务处理器，用于需要收集密钥的任务
fn run_parallel_processor_with_keys<F>(projects: Vec<String>, task_fn: F) -> Result<()>
where
    F: Fn(&str) -> Result<(String, String)> + Send + Sync + 'static + Clone,
{
    info!("开始并行处理 {} 个任务...", projects.len());
    let (tx, rx) = mpsc::channel();
    let mut handles = vec![];
    let mut job_count = 0;
    let mut project_iter = projects.into_iter().enumerate();
    
    // 启动初始批次的任务
    while job_count < *config::MAX_PARALLEL_JOBS {
        if let Some((index, project)) = project_iter.next() {
            let task_fn_clone = task_fn.clone();
            let tx_clone = tx.clone();
            
            let handle = thread::spawn(move || {
                let result = task_fn_clone(&project);
                tx_clone.send((index, result)).unwrap();
            });
            
            handles.push(handle);
            job_count += 1;
        } else {
            break;
        }
    }
    
    // 处理结果并启动新任务
    let mut results = vec![];
    let mut completed_count = 0;
    let total_count = handles.len() + project_iter.clone().count();
    
    while completed_count < total_count {
        if let Ok((_index, result)) = rx.recv() {
            results.push(result);
            completed_count += 1;
            
            // 启动新任务
            if let Some((_new_index, new_project)) = project_iter.next() {
                let task_fn_clone = task_fn.clone();
                let tx_clone = tx.clone();
                
                let handle = thread::spawn(move || {
                    let result = task_fn_clone(&new_project);
                    tx_clone.send((0, result)).unwrap(); // 使用0作为占位符索引
                });
                
                handles.push(handle);
            }
        }
    }
    
    // 等待所有线程结束
    for handle in handles {
        handle.join().unwrap();
    }
    
    let (successes, failures): (Vec<_>, Vec<_>) = results.into_iter().partition(Result::is_ok);
    let success_count = successes.len();
    let failed_count = failures.len();
    
    // 收集所有成功的密钥
    let mut keys = Vec::new();
    for success in successes {
        if let Ok((_project_id, api_key)) = success {
            keys.push(api_key);
        }
    }
    
    // 写入所有密钥到文件
    if !keys.is_empty() {
        // 写入纯净密钥文件 (每行一个)
        let pure_key_path = config::pure_key_file_path();
        let mut pure_content = String::new();
        for key in &keys {
            pure_content.push_str(key);
            pure_content.push('\n');
        }
        std::fs::write(&pure_key_path, &pure_content)
            .with_context(|| format!("无法写入纯净密钥文件: {:?}", pure_key_path))?;
        
        // 写入逗号分隔密钥文件
        let comma_key_path = config::comma_key_file_path();
        let comma_content = keys.join(",");
        std::fs::write(&comma_key_path, &comma_content)
            .with_context(|| format!("无法写入逗号分隔密钥文件: {:?}", comma_key_path))?;
    }
    
    for failure in failures {
        error!("任务失败: {:?}", failure.unwrap_err());
    }
    report_results(success_count, failed_count)
}

/// 通用的并行任务处理器，用于不需要收集密钥的任务
fn run_parallel_processor_without_keys<F>(projects: Vec<String>, task_fn: F) -> Result<()>
where
    F: Fn(&str) -> Result<String> + Send + Sync + 'static + Clone,
{
    info!("开始并行处理 {} 个任务...", projects.len());
    let (tx, rx) = mpsc::channel();
    let mut handles = vec![];
    let mut job_count = 0;
    let mut project_iter = projects.into_iter().enumerate();
    
    // 启动初始批次的任务
    while job_count < *config::MAX_PARALLEL_JOBS {
        if let Some((index, project)) = project_iter.next() {
            let task_fn_clone = task_fn.clone();
            let tx_clone = tx.clone();
            
            let handle = thread::spawn(move || {
                let result = task_fn_clone(&project);
                tx_clone.send((index, result)).unwrap();
            });
            
            handles.push(handle);
            job_count += 1;
        } else {
            break;
        }
    }
    
    // 处理结果并启动新任务
    let mut results = vec![];
    let mut completed_count = 0;
    let total_count = handles.len() + project_iter.clone().count();
    
    while completed_count < total_count {
        if let Ok((_index, result)) = rx.recv() {
            results.push(result);
            completed_count += 1;
            
            // 启动新任务
            if let Some((_new_index, new_project)) = project_iter.next() {
                let task_fn_clone = task_fn.clone();
                let tx_clone = tx.clone();
                
                let handle = thread::spawn(move || {
                    let result = task_fn_clone(&new_project);
                    tx_clone.send((0, result)).unwrap(); // 使用0作为占位符索引
                });
                
                handles.push(handle);
            }
        }
    }
    
    // 等待所有线程结束
    for handle in handles {
        handle.join().unwrap();
    }
    
    let (successes, failures): (Vec<_>, Vec<_>) = results.into_iter().partition(Result::is_ok);
    let success_count = successes.len();
    let failed_count = failures.len();
    for failure in failures {
        error!("任务失败: {:?}", failure.unwrap_err());
    }
    report_results(success_count, failed_count)
}

/// 批量创建密钥
pub fn batch_create_keys() -> Result<()> {
    info!("====== 高性能批量创建 Gemini API 密钥 ======");
    let num_projects_str: String = dialoguer::Input::new()
        .with_prompt("请输入要创建的项目数量 (例如: 50)")
        .interact_text()?;
    let num_projects: usize = num_projects_str.parse()
        .map_err(|_| GeminiError::ParseError("请输入一个有效的正整数".to_string()))?;

    let project_prefix: String = dialoguer::Input::new()
        .with_prompt("请输入项目前缀 (默认: gemini-pro)")
        .default(config::DEFAULT_PROJECT_PREFIX.to_string())
        .interact_text()?;

    println!("\n{}=== 操作确认 ==={}", utils::Style::Bold, utils::Style::Reset);
    println!("  计划创建项目数: {}{}{}", utils::Style::Bold, num_projects, utils::Style::Reset);
    println!("  项目前缀:       {}{}{}", utils::Style::Bold, project_prefix, utils::Style::Reset);
    println!("  并行任务数:     {}{}{}", utils::Style::Bold, *config::MAX_PARALLEL_JOBS, utils::Style::Reset);
    println!("  输出目录:       {}{}{}", utils::Style::Bold, config::output_dir().display(), utils::Style::Reset);
    println!("{}{}{}", utils::Color::Red, utils::Style::Bold, "警告: 大规模创建项目可能违反GCP服务条款或超出配额。");

    if !utils::ask_yes_no("确认要继续吗?")? {
        info!("操作已取消");
        return Ok(());
    }

    let projects_to_create: Vec<String> = (0..num_projects)
        .map(|_| utils::new_project_id(&project_prefix))
        .collect();
    run_parallel_processor_with_keys(projects_to_create, process_new_project_creation)
}

/// 从现有项目提取密钥
pub fn extract_from_existing_projects() -> Result<()> {
    info!("====== 从现有项目提取 Gemini API 密钥 ======");
    info!("获取活跃项目列表...");
    let output = gcp_command::run_gcloud_command_with_retry(&[
        "projects", "list",
        "--filter", "lifecycleState:ACTIVE",
        "--format", "value(projectId)"
    ])?;
    let all_projects: Vec<&str> = output.trim().split('\n').filter(|s| !s.is_empty()).collect();
    if all_projects.is_empty() {
        return Err(GeminiError::CommandError("未找到任何活跃项目".to_string()).into());
    }

    info!("找到 {} 个活跃项目。请选择要处理的项目:", all_projects.len());
    for (i, project) in all_projects.iter().enumerate() {
        println!("  {:3}. {}", i + 1, project);
    }

    let selection: String = dialoguer::Input::new()
        .with_prompt("请输入项目编号 (多个用空格隔开，或输入 'all' 处理全部)")
        .interact_text()?;

    let projects_to_process = if selection.trim().eq_ignore_ascii_case("all") {
        all_projects.iter().map(|s| s.to_string()).collect()
    } else {
        let mut selected = Vec::new();
        for num_str in selection.split_whitespace() {
            let num: usize = num_str.parse().map_err(|_| GeminiError::ParseError(format!("无效编号: {}", num_str)))?;
            if num < 1 || num > all_projects.len() {
                return Err(GeminiError::ParseError(format!("编号 {} 超出范围 (1-{})", num, all_projects.len())).into());
            }
            selected.push(all_projects[num - 1].to_string());
        }
        if selected.is_empty() {
            return Err(GeminiError::ParseError("未选择任何项目".to_string()).into());
        }
        selected
    };

    println!("\n{}=== 操作确认 ==={}", utils::Style::Bold, utils::Style::Reset);
    println!("  将为 {} 个现有项目提取新密钥", projects_to_process.len());
    println!("  并行任务数:     {}{}{}", utils::Style::Bold, *config::MAX_PARALLEL_JOBS, utils::Style::Reset);
    println!("  输出目录:       {}{}{}", utils::Style::Bold, config::output_dir().display(), utils::Style::Reset);

    if !utils::ask_yes_no("确认要继续吗?")? {
        info!("操作已取消");
        return Ok(());
    }
    run_parallel_processor_with_keys(projects_to_process, process_existing_project_extraction)
}

/// 批量删除项目
pub fn batch_delete_projects() -> Result<()> {
    info!("====== 批量删除项目 ======");
    let output = gcp_command::run_gcloud_command_with_retry(&[
        "projects", "list",
        "--filter", "lifecycleState:ACTIVE",
        "--format", "value(projectId)"
    ])?;
    let all_projects: Vec<&str> = output.trim().split('\n').filter(|s| !s.is_empty()).collect();
    if all_projects.is_empty() {
        return Err(GeminiError::CommandError("未找到任何活跃项目".to_string()).into());
    }

    let prefix: String = dialoguer::Input::new()
        .with_prompt("请输入要删除的项目前缀 (留空则匹配所有)")
        .interact_text()?;
    let projects_to_delete: Vec<String> = all_projects.iter()
        .filter(|s| prefix.is_empty() || s.starts_with(&prefix))
        .map(|s| s.to_string())
        .collect();

    if projects_to_delete.is_empty() {
        warn!("没有找到任何项目匹配前缀: '{}'", prefix);
        return Ok(());
    }

    println!("\n{}{}将要删除以下 {} 个项目:{}{}", utils::Color::Yellow, utils::Style::Bold, projects_to_delete.len(), utils::Style::Reset, utils::Color::Reset);
    for project in projects_to_delete.iter().take(20) {
        println!(" - {}", project);
    }
    if projects_to_delete.len() > 20 {
        println!("   ... 等等");
    }

    println!("\n{}{}{}!!! 警告：此操作不可逆 !!!{}{}", utils::Color::Red, utils::Style::Bold, "", utils::Style::Reset, utils::Color::Reset);
    let confirmation: String = dialoguer::Input::new().with_prompt("请输入 'DELETE' 来确认删除").interact_text()?;
    if confirmation != "DELETE" {
        info!("删除操作已取消");
        return Ok(());
    }
    
    run_parallel_processor_without_keys(projects_to_delete, |project_id| {
        info!("删除项目: {}", project_id);
        gcp_command::run_gcloud_command_with_retry(&["projects", "delete", project_id, "--quiet"])?;
        Ok(project_id.to_string())
    })
}

/// 报告操作结果
fn report_results(success_count: usize, failed_count: usize) -> Result<()> {
    println!("\n{}{}====== 操作完成：统计结果 ======{}", utils::Color::Green, utils::Style::Bold, utils::Style::Reset);
    info!("成功: {}", success_count);
    error!("失败: {}", failed_count);
    
    if success_count > 0 {
        let pure_key_path = config::pure_key_file_path();
        // 检查文件是否存在且不为空
        if pure_key_path.exists() && std::fs::metadata(&pure_key_path)?.len() > 0 {
            let keys = std::fs::read_to_string(&pure_key_path)?;
            let comma_separated = keys.lines().collect::<Vec<_>>().join(",");
            
            println!("\n{}{}======================================================{}", utils::Color::Purple, utils::Style::Bold, utils::Style::Reset);
            println!("      ✨ 最终API密钥 (逗号分隔) ✨");
            println!("======================================================{}", utils::Style::Reset);
            println!("{}{}{}", utils::Color::Green, utils::Style::Bold, comma_separated);
            println!("{}{}======================================================{}\n", utils::Color::Purple, utils::Style::Bold, utils::Style::Reset);
            
            info!("以上密钥已完整保存至目录: {}{}{}", utils::Style::Bold, config::output_dir().display(), utils::Style::Reset);
            info!("每行一个密钥文件: {}{}{}", utils::Style::Bold, pure_key_path.display(), utils::Style::Reset);
        } else {
            warn!("密钥文件为空或不存在");
        }
    }
    if failed_count > 0 {
        warn!("失败的项目ID列表保存在详细日志中: {}", config::detailed_log_file_path().display());
    }
    Ok(())
}