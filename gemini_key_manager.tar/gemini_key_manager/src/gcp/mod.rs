// gcp 模块的入口文件

// 声明子模块
pub mod gcp_command;
pub mod gcp_orchestrator;

// 导出 orchestrator 中的公共函数，以便 main.rs 可以调用
pub use gcp_orchestrator::{
    batch_create_keys,
    batch_delete_projects,
    extract_from_existing_projects,
};