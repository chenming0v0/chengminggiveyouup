#![allow(dead_code)]
use thiserror::Error;

#[derive(Error, Debug)]
pub enum GeminiError {
    #[error("配置错误: {0}")]
    ConfigurationError(String),

    #[error("解析错误: {0}")]
    ParseError(String),

    #[error("GCP API 错误: {0}")]
    ApiError(String),

    #[error("文件 IO 错误: {0}")]
    IoError(#[from] std::io::Error),

    #[error("GCP 命令执行失败: {0}")]
    CommandError(String),

    #[error("JSON 解析错误: {0}")]
    JsonError(#[from] serde_json::Error),

    #[error("用户取消了操作")]
    UserCancelled,

    #[error("网络错误: {0}")]
    NetworkError(String),

    #[error("并发错误: {0}")]
    ConcurrencyError(String),

    #[error("依赖项未找到: {0}")]
    DependencyNotFound(String),

    #[error("配额超出: {0}")]
    QuotaExceeded(String),

    #[error("权限被拒绝: {0}")]
    PermissionDenied(String),

    #[error("操作超时")]
    Timeout,
}