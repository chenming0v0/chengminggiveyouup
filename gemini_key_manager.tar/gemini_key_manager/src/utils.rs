use anyhow::{Context, Result};
use chrono::Local;
use fs2::FileExt;
use rand::Rng;
use std::fs::{self, OpenOptions};
use std::io::{self, Read, Write};
use std::process::Command;
use std::thread;
use std::time::Duration;

use crate::config;

// 终端颜色代码 (对应原脚本中的颜色定义)
#[derive(Clone, Copy)]
pub enum Color {
    Red, Green, Yellow, Purple, Cyan, Blue, Reset
}

impl Color {
    pub fn code(&self) -> &str {
        match self {
            Color::Red => "\x1B[0;31m",
            Color::Green => "\x1B[0;32m",
            Color::Yellow => "\x1B[0;33m",
            Color::Purple => "\x1B[0;35m",
            Color::Cyan => "\x1B[0;36m",
            Color::Blue => "\x1B[0;34m",
            Color::Reset => "\x1B[0m",
        }
    }
}

// 终端样式代码
#[derive(Clone, Copy)]
pub enum Style {
    Bold, Reset
}

impl Style {
    pub fn code(&self) -> &str {
        match self {
            Style::Bold => "\x1B[1m",
            Style::Reset => "\x1B[0m",
        }
    }
}

impl std::fmt::Display for Style {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.code())
    }
}

impl std::fmt::Display for Color {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.code())
    }
}

// ASCII 艺术 logo (对应原脚本中的 show_main_menu 里的 cat EOF 部分)
pub const LOGO: &str = r#"\x1B[1m\x1B[0;35m  ____ ____ ____ ____ ____ ____ _________ ____ ____ ____ 
 ||G |||e |||m |||i |||n |||i |||       |||K |||e |||y ||
 ||__|||__|||__|||__|||__|||__|||_______|||__|||__|||__||
 |/__\|/__\|/__\|/__\|/__\|/__\|/_______\|/__\|/__\|/__\|\x1B[0m"#;

/// 清空屏幕 (对应原脚本中的 clear 命令)
pub fn clear_screen() {
    if cfg!(target_os = "windows") {
        let _ = Command::new("cmd").args(&["/C", "cls"]).status();
    } else {
        let _ = Command::new("clear").status();
    }
}

/// 暂停并等待用户按键 (对应原脚本中的 read -n 1 -s -r)
pub fn pause() -> Result<()> {
    print!("按任意键继续...");
    io::stdout().flush()?;
    let mut input = [0u8; 1];
    io::stdin().read_exact(&mut input)?;
    Ok(())
}

/// 生成随机延迟 (对应原脚本中的 random_sleep 函数)
pub fn random_sleep() -> Result<()> {
    let mut rng = rand::thread_rng();
    let delay = rng.gen_range(0.0..=config::RANDOM_DELAY_MAX);
    let duration = Duration::from_secs_f64(delay);
    thread::sleep(duration);
    Ok(())
}

/// 生成新项目 ID (对应原脚本中的 new_project_id 函数)
pub fn new_project_id(prefix: &str) -> String {
    let mut rng = rand::thread_rng();
    let random_part: String = (0..4).map(|_| format!("{:02x}", rng.gen::<u8>())).collect();
    let timestamp = Local::now().timestamp();
    let project_id = format!("{}-{}-{}", prefix, timestamp, random_part);
    project_id.chars().take(30).collect()
}

/// 带锁定的密钥写入 (对应原脚本中的 write_key_atomic 函数)
pub fn write_key_atomic(api_key: &str) -> Result<()> {
    let pure_key_path = config::pure_key_file_path();
    let comma_key_path = config::comma_key_file_path();
    let lock_path = config::TEMP_DIR.path().join("keys.lock");

    // 创建锁定文件
    let lock_file = OpenOptions::new()
        .create(true)
        .write(true)
        .open(&lock_path)
        .with_context(|| format!("无法创建锁定文件: {:?}", lock_path))?;

    // 获取独占锁
    lock_file.lock_exclusive()
        .with_context(|| format!("无法获取文件锁: {:?}", lock_path))?;

    // 写入纯净密钥文件 (每行一个)
    let mut pure_file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(&pure_key_path)
        .with_context(|| format!("无法打开纯净密钥文件: {:?}", pure_key_path))?;
    writeln!(pure_file, "{}", api_key)
        .with_context(|| format!("无法写入纯净密钥文件: {:?}", pure_key_path))?;

    // 写入逗号分隔密钥文件
    let comma_exists = comma_key_path.exists() && fs::metadata(&comma_key_path)?.len() > 0;
    let mut comma_file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(&comma_key_path)
        .with_context(|| format!("无法打开逗号分隔密钥文件: {:?}", comma_key_path))?;

    if comma_exists {
        write!(comma_file, ",")
            .with_context(|| format!("无法写入逗号分隔符: {:?}", comma_key_path))?;
    }
    write!(comma_file, "{}", api_key)
        .with_context(|| format!("无法写入逗号分隔密钥文件: {:?}", comma_key_path))?;

    // 释放锁 (自动通过析构函数完成)
    Ok(())
}

/// 询问用户 yes/no (对应原脚本中的 ask_yes_no 函数)
pub fn ask_yes_no(prompt: &str) -> Result<bool> {
    loop {
        print!("{} [y/n]: ", prompt);
        io::stdout().flush()?;

        let mut input = String::new();
        io::stdin().read_line(&mut input)
            .context("读取用户输入失败")?;
        let input = input.trim().to_lowercase();

        match input.as_str() {
            "y" | "yes" => return Ok(true),
            "n" | "no" => return Ok(false),
            _ => println!("请输入 y 或 n.")
        }
    }
}

/// 获取当前 GCP 账户 (对应原脚本中的 gcloud config get-value account)
pub fn get_current_account() -> Result<String> {
    let output = Command::new("gcloud")
        .args(["config", "get-value", "account"])
        .output()
        .context("执行 gcloud 命令失败")?;

    if !output.status.success() {
        return Ok("未登录".to_string());
    }

    let account = String::from_utf8(output.stdout)?
        .trim()
        .to_string();

    Ok(account)
}

/// 清理守卫 (RAII 模式自动清理临时文件)
pub struct CleanupGuard;

impl CleanupGuard {
    pub fn new() -> Self {
        Self
    }
}

impl Drop for CleanupGuard {
    fn drop(&mut self) {
        // tempfile::TempDir 会在 Drop 时自动清理
        // 我们只需要确保 TEMP_DIR 被正确地 Drop
        // Lazy<T> 会在程序结束时 Drop 其内容
        println!("\n正在执行清理程序...");
        // 这里不需要手动删除，但可以打印信息
    }
}