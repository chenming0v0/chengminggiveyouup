use anyhow::Result;
use once_cell::sync::Lazy;
use std::env;
use std::path::PathBuf;
use tempfile::{tempdir, TempDir};

// 版本信息 (对应原脚本 VERSION)
pub const VERSION: &str = "3.5.3";

// 并行任务数 (对应原脚本 MAX_PARALLEL_JOBS)
pub static MAX_PARALLEL_JOBS: Lazy<usize> = Lazy::new(|| {
    env::var("CONCURRENCY")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(35)
});

// 默认项目前缀 (对应原脚本 project_prefix 默认值)
pub const DEFAULT_PROJECT_PREFIX: &str = "gemini-pro";

// 最大重试次数 (对应原脚本 MAX_RETRY_ATTEMPTS)
pub static MAX_RETRY_ATTEMPTS: Lazy<usize> = Lazy::new(|| {
    env::var("MAX_RETRY")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(3)
});

// 随机延迟最大值(秒) (对应原脚本 RANDOM_DELAY_MAX)
pub const RANDOM_DELAY_MAX: f64 = 1.5;

// 会话ID (对应原脚本 SESSION_ID)
pub static SESSION_ID: Lazy<String> = Lazy::new(|| {
    chrono::Local::now().format("%Y%m%d_%H%M%S").to_string()
});

// 输出目录路径 (对应原脚本 OUTPUT_DIR)
pub static OUTPUT_DIR: Lazy<PathBuf> = Lazy::new(|| {
    let dir = PathBuf::from(format!("gemini_session_{}", *SESSION_ID));
    if !dir.exists() {
        std::fs::create_dir_all(&dir).expect("无法创建输出目录");
    }
    dir
});
// 临时目录路径 (对应原脚本 TEMP_DIR)
pub static TEMP_DIR: Lazy<TempDir> = Lazy::new(|| {
    tempdir().expect("无法创建临时目录")
});

// 全局锁文件路径
pub static KEYS_LOCK_FILE: Lazy<std::fs::File> = Lazy::new(|| {
    let lock_path = TEMP_DIR.path().join("keys.lock");
    std::fs::OpenOptions::new()
        .create(true)
        .write(true)
        .open(&lock_path)
        .expect("无法创建全局锁文件")
});


/// 初始化配置 (现在由 Lazy 实现，此函数可以移除或保留用于预初始化)
pub fn init() -> Result<()> {
    // 预先访问 Lazy 变量以确保目录被创建
    let _ = &*OUTPUT_DIR;
    let _ = &*TEMP_DIR;
    Ok(())
}

/// 获取输出目录
pub fn output_dir() -> &'static PathBuf {
    &*OUTPUT_DIR
}

/// 获取纯净密钥文件路径 (对应原脚本 PURE_KEY_FILE)
pub fn pure_key_file_path() -> PathBuf {
    OUTPUT_DIR.join("all_keys_pure.txt")
}

/// 获取逗号分隔密钥文件路径 (对应原脚本 COMMA_KEY_FILE)
pub fn comma_key_file_path() -> PathBuf {
    OUTPUT_DIR.join("all_keys_comma_separated.txt")
}

/// 获取详细日志文件路径 (对应原脚本 DETAILED_LOG_FILE)
pub fn detailed_log_file_path() -> PathBuf {
    OUTPUT_DIR.join("detailed_run.log")
}