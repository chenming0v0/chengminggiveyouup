use anyhow::Result;
use log::{info, warn};
use std::io::{self, Write};
use std::process::exit;
use std::fs;

mod config;
mod errors;
mod gcp;
mod logging;
mod utils;

fn display_menu() {
    utils::clear_screen();
    println!("{}", utils::LOGO);
    println!("哈机密哈机密哈机密哈机密哈机密南北绿豆啊西巴呀南北绿豆");
    println!("-----------------------------------------------------");
    println!("  作者: 辰林 (脚本完全付费不分享，我很饿请给我钱)");
    println!("-----------------------------------------------------");
    println!("  当前账户: {}", utils::get_current_account().unwrap_or_else(|_| "未登录".to_string()));
    println!("  并行任务: {}", *config::MAX_PARALLEL_JOBS);
    println!("-----------------------------------------------------");
    
    // 显示最近生成的密钥内容
    let comma_key_path = config::comma_key_file_path();
    if comma_key_path.exists() {
        if let Ok(content) = fs::read_to_string(&comma_key_path) {
            if !content.trim().is_empty() {
                println!("\n{}{}======================================================{}", utils::Color::Purple, utils::Style::Bold, utils::Style::Reset);
                println!("      ✨ 最近生成的API密钥 (逗号分隔) ✨");
                println!("======================================================{}", utils::Style::Reset);
                println!("{}{}{}", utils::Color::Green, utils::Style::Bold, content.trim());
                println!("{}{}======================================================{}\n", utils::Color::Purple, utils::Style::Bold, utils::Style::Reset);
            }
        }
    }
    
    println!("{}{}请注意：滥用此脚本可能导致您的GCP账户受限。{}",
             utils::Color::Red, utils::Style::Bold, utils::Style::Reset);
    println!();
    println!("  1. 批量创建新项目并提取密钥");
    println!("  2. 从现有项目中提取 API 密钥");
    println!("  3. 批量删除指定前缀的项目");
    println!("  0. 退出脚本");
    println!();
}

fn main() -> Result<()> {
    // 初始化日志系统
    logging::init_logger()?;
    // 初始化配置 (现在是懒加载，但可以调用 init 预热)
    config::init()?;
    // 设置退出清理处理
    let _cleanup_guard = utils::CleanupGuard::new();

    // 主循环
    loop {
        display_menu();
        print!("请选择操作 [0-3]: ");
        io::stdout().flush()?;

        let mut input = String::new();
        io::stdin().read_line(&mut input)?;
        let choice = input.trim();

        match choice {
            "1" => gcp::batch_create_keys()?,
            "2" => gcp::extract_from_existing_projects()?,
            "3" => gcp::batch_delete_projects()?,
            "0" => {
                info!("感谢使用！");
                exit(0);
            }
            _ => {
                warn!("无效输入，请输入 0, 1, 2 或 3");
                utils::pause()?;
            }
        }
    }
}