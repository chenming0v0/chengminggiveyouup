use anyhow::{Context, Result};
use chrono::Local;
use log::{Level, LevelFilter, Metadata, Record};
use std::fs::OpenOptions;
use std::io::Write;

use crate::config;

use std::sync::Mutex;

// 自定义日志记录器
struct GeminiLogger {
    file_logger: Option<Mutex<std::fs::File>>,
}

impl log::Log for GeminiLogger {
    fn enabled(&self, metadata: &Metadata) -> bool {
        metadata.level() <= Level::Info
    }

    fn log(&self, record: &Record) {
        if !self.enabled(record.metadata()) {
            return;
        }

        let timestamp = Local::now().format("%Y-%m-%d %H:%M:%S");
        let level = record.level();
        let message = record.args();

        // 控制台日志带颜色
        let (color, level_str) = match level {
            Level::Error => (crate::utils::Color::Red, "ERROR"),
            Level::Warn => (crate::utils::Color::Yellow, "WARN"),
            Level::Info => (crate::utils::Color::Cyan, "INFO"),
            Level::Debug => (crate::utils::Color::Purple, "DEBUG"),
            Level::Trace => (crate::utils::Color::Blue, "TRACE"),
        };

        // 输出到控制台
        eprintln!("{}{}[{}] [{}] {}{}",
            color,
            crate::utils::Style::Bold,
            timestamp,
            level_str,
            message,
            crate::utils::Style::Reset
        );

        // 同时写入日志文件 (无颜色)
        if let Some(file) = self.file_logger.as_ref() {
            if let Ok(mut file_lock) = file.lock() {
                let log_line = format!("[{}] [{}] {}", timestamp, level_str, message);
                let _ = writeln!(file_lock, "{}", log_line);
            }
        }
    }

    fn flush(&self) {}
}

/// 初始化日志系统
pub fn init_logger() -> Result<()> {
    let log_file_path = config::detailed_log_file_path();

    // 创建日志文件
    let file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(&log_file_path)
        .with_context(|| format!("无法创建日志文件: {:?}", log_file_path))?;

    // 初始化自定义日志器
    static LOGGER: std::sync::OnceLock<GeminiLogger> = std::sync::OnceLock::new();
    LOGGER.set(GeminiLogger { file_logger: Some(Mutex::new(file)) })
        .map_err(|_| anyhow::anyhow!("日志器已初始化"))?;

    log::set_logger(LOGGER.get().unwrap())
        .map(|()| log::set_max_level(LevelFilter::Info))
        .context("无法设置日志器")?;

    Ok(())
}