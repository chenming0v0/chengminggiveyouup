#!/bin/bash

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # 无颜色

# 函数：打印信息
info() {
    echo -e "${GREEN}[INFO] $1${NC}"
}

# 函数：打印警告
warn() {
    echo -e "${YELLOW}[WARN] $1${NC}"
}

# 函数：打印错误并退出
error_exit() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

# 步骤 1: 检查并安装必要的系统依赖
info "步骤 1: 检查并安装系统依赖..."
if ! command -v curl &> /dev/null || ! dpkg -s build-essential &> /dev/null; then
    info "需要安装 'curl' 和 'build-essential'。请输入您的 sudo 密码。"
    sudo apt-get update || error_exit "apt-get update 失败"
    sudo apt-get install -y curl build-essential || error_exit "安装 curl 或 build-essential 失败"
else
    info "系统依赖已满足。"
fi

# 步骤 2: 检查并安装 Rust
info "步骤 2: 检查并安装 Rust..."
if ! command -v cargo &> /dev/null; then
    info "未找到 Rust。正在使用 rustup 安装..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
    rustup default stable
    info "Rust 安装完成。"
else
    info "Rust 已安装。"
    # 检查是否设置了默认工具链
    if ! rustup toolchain list | grep -q "stable"; then
        info "未找到 stable 工具链，正在安装..."
        rustup install stable
    fi
    rustup default stable
    source "$HOME/.cargo/env"
fi

# 步骤 3: 检查 gcloud CLI
info "步骤 3: 检查 gcloud CLI..."
if ! command -v gcloud &> /dev/null; then
    warn "未找到 gcloud CLI。"
    warn "请按照官方文档手动安装和配置 gcloud CLI:"
    warn "https://cloud.google.com/sdk/docs/install"
    read -p "安装并配置好 gcloud 后，按 [Enter] 继续..."
    if ! command -v gcloud &> /dev/null; then
        error_exit "gcloud CLI 仍未安装。请先完成安装再运行此脚本。"
    fi
else
    info "gcloud CLI 已安装。"
fi

# 步骤 4: 编译 Rust 项目
info "步骤 4: 编译 Rust 项目 (gemini_key_manager)..."
if [ ! -f "Cargo.toml" ]; then
    error_exit "未在当前目录中找到 Cargo.toml。请确保您在 gemini_key_manager 项目的根目录中运行此脚本。"
fi
cargo build --release || error_exit "项目编译失败。"
info "项目编译成功！"

# 步骤 5: 运行项目
info "步骤 5: 运行 gemini_key_manager..."
./target/release/gemini_key_manager